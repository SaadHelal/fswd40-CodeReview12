<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_Saad_Helal_traveler
 */

if ( ! is_active_sidebar( 'sidebar-1' ) ) {
	return;
}
?>
<h1 class="text-center font-italic">Welcom to Mount Everest Blog!</h1>
<hr>
<aside id="secondary" class="widget-area">
	<div class= "container">
    	<div class= "row">
    	<div class="col-lg-12">
    	<?php dynamic_sidebar( 'sidebar-1' ); ?>
		</div>

    	<div class="col-lg-12">
           <?php if (have_posts()) : ?>
                    <?php 
                  
                     while ( have_posts() ) : the_post(); ?>
                     
                    <div class='card p-2' id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                        <div class="post-header text-center">
                        <h2><a href="<?php the_permalink(); ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_title(); ?></a></h2>
                        <div class="author"> <h3><?php the_author(); ?></h3></div>
                        
                        </div><!--end post header-->
                        
                        <?php if ( function_exists( 'add_theme_support' ) ) the_post_thumbnail(); ?>
                        <?php the_content(); ?>
                        <div class="date text-right"><?php the_time( 'M-j-y' ); ?></div>
                        <button class="btn btn-outline-secondary col-lg-12">
                        <?php edit_post_link();?>
                        <?php wp_link_pages(); ?>
                        </button> 
                        <!--end entry-->
                        <div class="post-footer">
                        <button class="btn btn-outline-secondary col-lg-12" >
                        <div class=""><?php comments_popup_link( 'Leave a Comment', '1 Comment', '% Comments' ); ?></div></button>
                        
                        
                        </div><!--end post footer-->
                        </div><!--end post-->
                        <br>
                    <?php endwhile; /* rewind or continue if all posts have been fetched */ ?>
                        <div class="navigation index">
                        <div class="alignleft"><?php next_posts_link( 'Older Entries' ); ?></div>
                        <div class="alignright"><?php previous_posts_link( 'Newer Entries' ); ?></div>
                        </div><!--end navigation-->
                    <?php else : ?>
                    <?php endif; ?>
                    </div>
</aside><!-- #secondary -->
