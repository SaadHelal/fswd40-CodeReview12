<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package cr12_Saad_Helal_traveler
 */

?>
    <!doctype html>
    <html <?php language_attributes(); ?>>

    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="profile" href="https://gmpg.org/xfn/11">
        <?php wp_head(); ?>
    </head>

    <body <?php body_class(); ?>>
        
        
       <nav class="navbar navbar-expand-lg" style="height:70px">
           <a href="<?php echo get_home_url();?>">
       <img class="img-responsive" src="<?php echo get_template_directory_uri(); ?>/img/logo.png" alt="logo" width="100"> </a>
        
                        <div class="collapse navbar-collapse" id="navbarSupportedContent">
                            <?php
                                wp_nav_menu( array(
                                    'theme_location' => 'menu-1',
                                    'menu_id'        => 'primary-menu',
                                    'menu_class'     => 'navbar-nav mr-auto',
                                    'depth'          => 3,
                                    'fallback_cb'    => 'WP_Bootstrap_Navwalker::fallback',
                                    'walker'         => new wp_bootstrap_navwalker(),
                                ) );
                            ?>
                        </div>
                       
                </nav>
                <div id="carouselExampleIndicators" class="carousel slide mt-3 mb-5" data-ride="carousel">
                    <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">
                <div class="carousel-item active">
                <img class="d-block w-100" src="https://www.nationsonline.org/gallery/Nepal/Mera-Peak-Panorama-Nepal.jpg" alt="First slide" style="height:600px">
                </div>
                <div class="carousel-item">
                <img class="d-block w-100" src="http://www.explor8ion.com/sites/default/files/images/scrambles/lougheed-ii-iii/redo/lougeed-050.jpg" alt="Second slide" style="height:600px">
                </div>
                <div class="carousel-item">
                <img class="d-block w-100" src="https://www.visitjotunheimen.com/imageresizer/?image=%2Fdbimgs%2F6%20BREVANDRING%20-%20b%C3%B8verbrean17_1%20-%20Live-Bildegalleri1750x600px.jpg&action=MediaGallery" alt="Third slide"  style="height:600px">
                </div>
            </div>
            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
            </div>